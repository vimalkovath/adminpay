export interface AppPage {
  url: string;
  icon: object;
  title: string;
}
